package com.example.utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.example.entity.ZipCodeEntity;

public class ZipCodeUtility {

	private ZipCodeUtility() {

	}

	private static Pattern zipPattern = Pattern.compile("(\\d{5})");

	/**
	 * Consolidates a list of ZipCodeRange objects into the shortest possible
	 * grouping of ranges.
	 * 
	 * @param zipCodeRanges The list of ZipCodeRange objects to be processed
	 * @return A List of sorted (ascending) ZipCodeRange objects
	 */
	public static List<ZipCodeEntity> arrangeZipCodesRange(List<ZipCodeEntity> zipCodeRanges) {
		Set<ZipCodeEntity> sortedRanges = new TreeSet<>(ZipCodeEntity.COMPARATOR);
		if (zipCodeRanges != null) {
			zipCodeRanges.sort(ZipCodeEntity.COMPARATOR);
			for (ZipCodeEntity zcr : zipCodeRanges) {
				// create a copy, so the original object is not change by a future merge
				ZipCodeEntity merge = ZipCodeEntity.copy(zcr);
				boolean overlap = false;
				for (ZipCodeEntity existingRange : sortedRanges) {
					if (existingRange.isMergeable(merge)) {
						existingRange.merge(merge);
						overlap = true;
						break;
					}
				}
				if (!overlap) {
					sortedRanges.add(merge);
				}
			}
		}
		return new ArrayList<>(sortedRanges);
	}

	/**
	 * Checks if the given ZIP codes should be excluded/removed by 
	 * known ZIP code ranges.
	 */
	public static boolean isZipCodeExcluded(String zipCode, List<ZipCodeEntity> excludeRange) {
		boolean result = false;
		if (zipCode != null) {
			Matcher matcher = zipPattern.matcher(zipCode);
			if (matcher.matches()) {
				result = isExcluded(Integer.valueOf(matcher.group(1)), excludeRange);
			} else {
				throw new IllegalArgumentException("Invalid ZIP code: " + zipCode);
			}
		}
		return result;
	}

	/**
	 * Checks if the given ZIP code should be excluded (contained) by any of the
	 * known ZIP code ranges.
	 */
	public static boolean isExcluded(int zipCode, List<ZipCodeEntity> excludeRange) {
		boolean result = false;
		if (zipCode < 0 || zipCode > 99999) {
			throw new IllegalArgumentException("Invalid ZIP code: " + zipCode);
		}
		if (excludeRange != null) {
			for (ZipCodeEntity range : excludeRange) {
				if (zipCode >= range.getStart() && zipCode <= range.getEnd()) {
					result = true;
					break;
				}
			}
		}
		return result;
	}

	/**
	 * Checks of the given ZIP code is in the specific range. Both start and end
	 * ranges values are considered
	 */
	public static boolean isZipCodeInRange(int zipCode, ZipCodeEntity range) {
		boolean result = false;
		if (range != null) {
			result = (range.getStart() <= zipCode && zipCode <= range.getEnd());
		}
		return result;
	}

}
