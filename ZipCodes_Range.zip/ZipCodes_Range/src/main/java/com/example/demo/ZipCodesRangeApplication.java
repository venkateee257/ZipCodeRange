package com.example.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.ZipCodeEntity;
import com.example.utilities.ZipCodeUtility;

@SpringBootApplication
public class ZipCodesRangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZipCodesRangeApplication.class, args);
		
		List<ZipCodeEntity> inputZipCodeRanges = new ArrayList<>();

		try (BufferedReader br = new BufferedReader(
				new InputStreamReader(ZipCodesRangeApplication.class.getResourceAsStream("/ZipCodeList.txt")))) {
			for (String line; (line = br.readLine()) != null;) {
				inputZipCodeRanges.add(new ZipCodeEntity(line));
			}
		} catch (IOException e) {

			System.err.println(e.getMessage());
		}
		
		// we can use either Apache Loggers or JSON Loggers, here i am using Sysout
		System.out.println("Input ZipCode Ranges:\n" + inputZipCodeRanges);

		List<ZipCodeEntity> excludedZipCodes = ZipCodeUtility.arrangeZipCodesRange(inputZipCodeRanges);
		System.out.println("Consolidated ZipCode Ranges:" + excludedZipCodes);

	}
	}

	

