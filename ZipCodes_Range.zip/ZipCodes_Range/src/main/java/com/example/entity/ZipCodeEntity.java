package com.example.entity;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static com.example.utilities.ZipCodeUtility.isZipCodeInRange;;

public class ZipCodeEntity implements Comparable<ZipCodeEntity> {

	private int start;
	private int end;
	private static Pattern arangePattern = Pattern.compile("\\[?\\s*(\\d{1,5})\\s*,\\s*(\\d{1,5})\\s*]?");

	
	public static Comparator<ZipCodeEntity> COMPARATOR = Comparator.comparingInt(ZipCodeEntity::getStart)
			.thenComparingInt(ZipCodeEntity::getEnd);

	/**
	 * Sets the start and end ZIP code ranges.
	 * @throws IllegalArgumentException when the format of the range is incorrect
	 *
	 */
	public ZipCodeEntity(String range) {
		Matcher matcher = arangePattern.matcher(range);
		if (matcher.matches()) {
			setZipCodesRange(Integer.valueOf(matcher.group(1)), Integer.valueOf(matcher.group(2)));
		} else {
			throw new IllegalArgumentException("Invalid ZIP code range: " + range);
		}
	}

	/**
	 * Sets the start and end ZIP code ranges.
	 * 
	 * @param range An int[] of exactly two ZIP code values ranging from 0-99999,
	 *              representing the start and end range
	 * @throws IllegalArgumentException when the ZIP code value is not within the
	 *                                  supported range
	 */
	public ZipCodeEntity(int[] range) {
		if (range.length == 2) {
			setZipCodesRange(range[0], range[1]);
		} else {
			throw new IllegalArgumentException(
					"Invalid ZIP code range - exactly two values must be provided: " + Arrays.toString(range));
		}
	}

	/**
	 * Sets the start and end ZIP code ranges.
	 * 
	 * @param range A List&lt;Integer&gt; of exactly two ZIP code values ranging
	 *              from 0-99999, representing the start and end range
	 * @throws IllegalArgumentException when the ZIP code value is not within the
	 *                                  supported range
	 */
	public ZipCodeEntity(List<Integer> range) {
		if (range.size() == 2) {
			setZipCodesRange(range.get(0), range.get(1));
		} else {
			throw new IllegalArgumentException(
					"Invalid ZIP code range - exactly two values must be provided: " + range);
		}
	}

	
	public static ZipCodeEntity copy(ZipCodeEntity range) {
		return new ZipCodeEntity(new int[] { range.getStart(), range.getEnd() });
	}


	@Override
	public int compareTo(ZipCodeEntity range) {
		return Comparator.comparing(ZipCodeEntity::getStart).thenComparing(ZipCodeEntity::getEnd).compare(this, range);
	}


	public int getEnd() {
		return this.end;
	}

	
	public int getStart() {
		return this.start;
	}

	

	/**
	 * Merges any overlapped values from the specified range into this instance.
	 * 
	 * @param range The ZipCodeRange object to merge into this instance
	 */
	public void merge(ZipCodeEntity range) {
		if (range != null && isMergeable(range)) {
			if (range.start < this.start) {
				this.start = range.start;
			}
			if (range.end > this.end) {
				this.end = range.end;
			}
		}
	}

	public boolean isMergeable(ZipCodeEntity merge) {
		boolean result = false;
		if (merge != null) {
			result = ((merge.end + 1 == this.start) || (merge.start - 1) == this.end || isZipCodeInRange(merge.start, this)
					|| isZipCodeInRange(merge.end, this) || isZipCodeInRange(this.start, merge));
		}
		return result;
	}
	

	/**
	 * @param start The starting ZIP code
	 * @param end   The ending ZIP code
	 * minimum and maximum values will be determined internally
	 */
	private void setZipCodesRange(int start, int end) {
		if (start < 0 || start > 99999) {
			throw new IllegalArgumentException("Provide correct start value for ZIP code range: " + start);
		} else if (end < 0 || end > 99999) {
			throw new IllegalArgumentException("Provide correct end value for ZIP code range: " + end);
		}
		if (start < end) {
			this.start = start;
			this.end = end;
		} else if (start > end) {
			this.start = end;
			this.end = start;
		} else {
			this.start = start;
			this.end = start;
		}
	}

	
	@Override
	public String toString() {
		String indent = "\n\t";
		return "ZipCodeRange {" + indent + "start: " + String.format("%05d", this.start) + indent + "end: "
				+ String.format("%05d", this.end) + "\n}";
	}

}
